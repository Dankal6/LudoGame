#pragma once
#include "Header.h"

void init(_player*);
