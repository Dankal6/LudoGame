#pragma once
#include "Header.h"

void init_board(_board*);

void prepare_bases(_board*, _pawn*);

void prepare_goals(_board*);

void prepare_road(_field*);

