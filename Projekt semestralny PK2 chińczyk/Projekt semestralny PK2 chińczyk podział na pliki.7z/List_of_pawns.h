#pragma once
#include "Header.h"

void pop_front(_pawn **);

void pop_by_index(_pawn **, int);

void push_back(_pawn **, _pawn *);

int position_in_list(_pawn**, _pawn*);